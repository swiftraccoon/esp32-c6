//! Shared, allocation-free measurement and serial reporting for both adapters.

use core::fmt::{self, Write};
use core::hint::black_box;

use bench_core::{DEFAULT_ROUNDS, DEFAULT_SAMPLES, DEFAULT_SEED, WORKLOAD_ID, workload};
use esp_hal::time::{Duration, Instant};

const WARMUP_ITERATIONS: u32 = 8;
const SAMPLE_COUNT: usize = DEFAULT_SAMPLES as usize;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
struct Sample {
    elapsed: Duration,
    checksum: u32,
}

impl Sample {
    const EMPTY: Self = Self {
        elapsed: Duration::ZERO,
        checksum: 0,
    };
}

/// Measures one complete run before writing any protocol events.
///
/// The caller initializes the HAL at 160 MHz and owns a blocking UART0 writer.
/// Samples use the HAL's monotonic system timer, with 1 microsecond resolution.
/// Each elapsed value includes two timer observations and the `black_box`
/// boundaries. Timer overhead is recorded separately and is never subtracted.
/// There is no allocation, serial access, or formatting in a measured region.
///
/// # Errors
///
/// Returns a formatting error on serial failure. This stops output, so the host
/// cannot validate a complete run. The caller must not emit a success afterward.
pub(super) fn run(mut writer: impl Write, platform: &str) -> fmt::Result {
    for _ in 0..WARMUP_ITERATIONS {
        black_box(workload(black_box(DEFAULT_SEED), black_box(DEFAULT_ROUNDS)));
    }

    let mut compute = [Sample::EMPTY; SAMPLE_COUNT];
    let mut timer_overhead = [Sample::EMPTY; SAMPLE_COUNT];

    for sample in &mut compute {
        let start = Instant::now();
        let checksum = black_box(workload(black_box(DEFAULT_SEED), black_box(DEFAULT_ROUNDS)));
        let elapsed = start.elapsed();
        *sample = Sample { elapsed, checksum };
    }

    for sample in &mut timer_overhead {
        let start = Instant::now();
        black_box(());
        let elapsed = start.elapsed();
        *sample = Sample {
            elapsed,
            checksum: 0,
        };
    }

    writeln!(
        writer,
        "{{\"protocol\":1,\"event\":\"hello\",\"platform\":\"{platform}\",\"cpu_mhz\":160,\"sample_count\":{DEFAULT_SAMPLES},\"seed\":{DEFAULT_SEED},\"rounds\":{DEFAULT_ROUNDS},\"workload\":\"{WORKLOAD_ID}\",\"warmup_iterations\":{WARMUP_ITERATIONS},\"timer_resolution_ns\":1000}}"
    )?;

    write_samples(&mut writer, "compute", DEFAULT_ROUNDS, &compute)?;
    write_samples(&mut writer, "timer-overhead", 0, &timer_overhead)?;

    writeln!(
        writer,
        "{{\"protocol\":1,\"event\":\"complete\",\"samples\":{},\"compute_samples\":{DEFAULT_SAMPLES},\"timer_overhead_samples\":{DEFAULT_SAMPLES}}}",
        2 * DEFAULT_SAMPLES,
    )
}

fn write_samples(
    mut writer: impl Write,
    benchmark: &str,
    iterations: u32,
    samples: &[Sample],
) -> fmt::Result {
    for (index, sample) in samples.iter().enumerate() {
        // This run lasts seconds, far below the system timer's seven-year wrap.
        // Multiplying these bounded microsecond durations by 1000 fits in u64.
        let elapsed_ns = sample.elapsed.as_micros() * 1000;
        writeln!(
            writer,
            "{{\"protocol\":1,\"event\":\"sample\",\"benchmark\":\"{benchmark}\",\"index\":{index},\"iterations\":{iterations},\"elapsed_ns\":{elapsed_ns},\"checksum\":{}}}",
            sample.checksum,
        )?;
    }
    Ok(())
}
