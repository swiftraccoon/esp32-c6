//! ESP32-C6 ESP-IDF/FreeRTOS baseline. See the build and review records.

use std::hint::black_box;
use std::io::{self, Write};
use std::time::Duration;

use bench_core::{DEFAULT_ROUNDS, DEFAULT_SAMPLES, DEFAULT_SEED, WORKLOAD_ID, workload};

/// One result, retained in bounded stack storage until timing has finished.
#[derive(
    Clone, Copy, Debug, Default, Eq, Hash, PartialEq, serde::Serialize, serde::Deserialize,
)]
struct Sample {
    elapsed_ns: u64,
    checksum: u32,
}

/// A monotonic timestamp in microseconds since ESP-IDF startup.
#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
struct TimestampMicros(i64);

impl TimestampMicros {
    fn now() -> Self {
        // SAFETY: esp_timer_get_time takes no arguments, retains no pointers,
        // and is callable after IDF startup from this single main task. Its
        // generated C ABI binding returns microseconds as a signed 64-bit value.
        Self(unsafe { esp_idf_sys::esp_timer_get_time() })
    }

    /// Returns elapsed nanoseconds at the timer's 1,000 ns resolution.
    ///
    /// # Errors
    /// Returns an error if the timer moved backwards or conversion overflowed.
    fn elapsed_ns(self, end: Self) -> io::Result<u64> {
        let elapsed_us = end
            .0
            .checked_sub(self.0)
            .ok_or_else(|| io::Error::other("esp timer subtraction overflowed"))?;
        let elapsed_us =
            u64::try_from(elapsed_us).map_err(|_| io::Error::other("esp timer moved backwards"))?;
        elapsed_us
            .checked_mul(1_000)
            .ok_or_else(|| io::Error::other("nanosecond conversion overflowed"))
    }
}

/// Buffers samples and emits the complete version 1 protocol run over UART0.
///
/// # Errors
/// Returns UART write/flush failures and rejected timer intervals. Failures
/// before completion leave an incomplete run; the host validates received bytes.
fn run() -> io::Result<()> {
    std::thread::sleep(Duration::from_secs(2));
    for _ in 0..8 {
        black_box(workload(black_box(DEFAULT_SEED), black_box(DEFAULT_ROUNDS)));
    }
    let mut compute = [Sample::default(); DEFAULT_SAMPLES as usize];
    let mut timer_overhead = [Sample::default(); DEFAULT_SAMPLES as usize];

    for sample in &mut compute {
        let start = TimestampMicros::now();
        let checksum = black_box(workload(black_box(DEFAULT_SEED), black_box(DEFAULT_ROUNDS)));
        let end = TimestampMicros::now();
        *sample = Sample {
            elapsed_ns: start.elapsed_ns(end)?,
            checksum,
        };
    }
    for sample in &mut timer_overhead {
        let start = TimestampMicros::now();
        black_box(());
        let end = TimestampMicros::now();
        *sample = Sample {
            elapsed_ns: start.elapsed_ns(end)?,
            checksum: 0,
        };
    }

    let stdout = io::stdout();
    let mut output = stdout.lock();
    writeln!(
        output,
        "{{\"protocol\":1,\"event\":\"hello\",\"platform\":\"esp-idf-freertos\",\"cpu_mhz\":160,\"sample_count\":{DEFAULT_SAMPLES},\"seed\":{DEFAULT_SEED},\"rounds\":{DEFAULT_ROUNDS},\"workload\":\"{WORKLOAD_ID}\",\"warmup_iterations\":8,\"timer_resolution_ns\":1000}}"
    )?;
    for (index, sample) in compute.into_iter().enumerate() {
        writeln!(
            output,
            "{{\"protocol\":1,\"event\":\"sample\",\"benchmark\":\"compute\",\"index\":{index},\"iterations\":{DEFAULT_ROUNDS},\"elapsed_ns\":{},\"checksum\":{}}}",
            sample.elapsed_ns, sample.checksum
        )?;
    }
    for (index, sample) in timer_overhead.into_iter().enumerate() {
        writeln!(
            output,
            "{{\"protocol\":1,\"event\":\"sample\",\"benchmark\":\"timer-overhead\",\"index\":{index},\"iterations\":0,\"elapsed_ns\":{},\"checksum\":0}}",
            sample.elapsed_ns
        )?;
    }
    writeln!(
        output,
        "{{\"protocol\":1,\"event\":\"complete\",\"samples\":128,\"compute_samples\":64,\"timer_overhead_samples\":64}}"
    )?;
    output.flush()
}

fn main() {
    esp_idf_sys::link_patches();
    if let Err(error) = run() {
        // The collector checks the records actually received. Report failure
        // outside measured regions; final flush can fail after completion queued.
        eprintln!("benchmark failed: {error}");
    }
}
