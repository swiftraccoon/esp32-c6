#![no_main]
#![no_std]

use ariel_os::thread::sync::Channel;
use ariel_os::{debug::ExitCode, log::*};

static CHANNEL: Channel<u8> = Channel::new();

#[ariel_os::thread(autostart)]
fn thread0() {
    let my_id = ariel_os::thread::current_tid().unwrap();
    info!("[Thread {:?}] Sending a message...", my_id);
    CHANNEL.send(&42);
}

#[ariel_os::thread(autostart, priority = 2)]
fn thread1() {
    let my_id = ariel_os::thread::current_tid().unwrap();
    info!("[Thread {:?}] Waiting to receive a message...", my_id);
    let recv = CHANNEL.recv();
    info!(
        "[Thread {:?}] The answer to the Ultimate Question of Life, the Universe, and Everything is: {}.",
        my_id, recv
    );
    ariel_os::debug::exit(ExitCode::SUCCESS);
}
