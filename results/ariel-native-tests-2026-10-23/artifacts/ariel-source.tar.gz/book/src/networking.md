# Networking

## Enabling Networking

Networking is enabled by selecting the `network` [laze module][laze-modules-book].
When enabled, a network link is automatically selected among the ones available on the target board, currently preferring Wi-Fi networking.
Overriding this default selection is possible by explicitly selecting the desired [network link module](#network-link-selection).

## Network Link Selection

Ariel OS currently supports three different networking links: Ethernet, USB CDC-NCM (i.e., Ethernet over USB) and Wi-Fi.
Boards may support all of them, only some of them, or none of them. However, currently the network stack supports at most one interface.

Which link layer is used for networking is selected at compile time,
through [laze modules][laze-modules-book].

- `ethernet-stm32`: Selects Ethernet on STM32 chips, through the [built-in MAC][ethernet-builtin-mac-book].
- `ethernet-wiznet-*`: Selects [Ethernet using an external MAC chip][ethernet-external-mac-book], through the selected WIZnet chip.
- `ltem-nrf-modem`: Selects LTE-M on nRF91 MCUs.
- `usb-ethernet`: Selects Ethernet over USB (currently using USB CDC-NCM).
- `wifi-cyw43`: Selects Wi-Fi using the CYW43 chip along an RP2040 or RP235x MCU (e.g., on the Raspberry Pi Pico W or Pico 2 W).
- `wifi-esp`: Selects Wi-Fi on an ESP32 MCU.

## Network Credentials

### Wi-Fi

For Wi-Fi, the network credentials have to be supplied via environment variables:

```sh
CONFIG_WIFI_NETWORK=<ssid> CONFIG_WIFI_PASSWORD=<pwd> laze build ...
```

### Cellular Networking

> [!WARNING]
> This module is still experimental and only supports the nRF91 family of microcontrollers.

The following environment variables can be used to authenticate to the cellular network:

- `CONFIG_CELLULAR_PDN_APN`: The access point name to connect to.
- `CONFIG_CELLULAR_PDN_AUTHENTICATION_PROTOCOL`: The protocol used to authenticate, must be one of `NONE`, `PAP`, or `CHAP`.
  If `PAP` or `CHAP` is selected, `CONFIG_CELLULAR_PDN_USERNAME` and `CONFIG_CELLULAR_PDN_PASSWORD` need to be set.
  `NONE` doesn't require more environment variables.
- `CONFIG_CELLULAR_PDN_USERNAME`: The username used to authenticate to the network.
- `CONFIG_CELLULAR_PDN_PASSWORD`: The password used to authenticate to the network.
- `CONFIG_SIM_PIN`: The code to unlock the SIM.

If some environment variables are not configured, the default provided by the modem and SIM will be used.

## Using the Networking Link on the Device

### Network Configuration

> [!IMPORTANT]
> When selecting a `network-config-*` [laze module](./build-system.md#laze-modules), this module must be placed *before* the `network` laze module in the [`selects` array][enabling-laze-modules-book].

> [!NOTE]
> IPv4 and IPv6 configurations are ignored when using `ltem-nrf-modem`, and is instead set by the modem.

#### IPv4

Support for IPv4 is enabled by default.
When unneeded, it can be disabled by disabling the `ipv4` [laze module](./build-system.md#laze-modules).

DHCP is used by default for IPv4 network configuration, including for address allocation.
This is enabled by the `network-config-ipv4-dhcp` [laze module](./build-system.md#laze-modules), selected by default for IPv4.

In order to provide a static configuration instead, select the `network-config-ipv4-static` [laze module](./build-system.md#laze-modules), which will take precedence.
The configuration can be customized with the following environment variables:

| Variable                                 | Default      |
| --                                       | --           |
| `CONFIG_NET_IPV4_STATIC_ADDRESS`         | `10.42.0.61` |
| `CONFIG_NET_IPV4_STATIC_CIDR_PREFIX_LEN` | `24`         |
| `CONFIG_NET_IPV4_STATIC_GATEWAY_ADDRESS` | `10.42.0.1`  |

#### IPv6

Support for IPv6 is not currently enabled by default, but can be enabled by selecting the `ipv6` [laze module](./build-system.md#laze-modules).
IPv4 and IPv6 can both be enabled at the same time.

IPv6 currently only supports static configuration, which is therefore enabled by default; it can also be explicitly selected with the `network-config-ipv6-static` [laze module](./build-system.md#laze-modules).

The configuration must be customized with the following environment variables:

| Variable                                 | Default                     |
| --                                       | --                          |
| `CONFIG_NET_IPV6_STATIC_ADDRESS`         | *No default, but mandatory* |
| `CONFIG_NET_IPV6_STATIC_CIDR_PREFIX_LEN` | `64`                        |
| `CONFIG_NET_IPV6_STATIC_GATEWAY_ADDRESS` | *No default, but mandatory* |

> [!NOTE]
> Non-static IPv6 address allocation will be supported in the future.

#### Custom Configuration Provider

Instead of using DHCP or passing static configuration through environment variables it is also possible to use a custom configuration provider if needed.
To do that, the `network-config-override` [laze module](./build-system.md#laze-modules) needs to be enabled, and the [`#[ariel_os::config]` attribute macro][config-attr-macro-rustdoc] can be used to provide the configuration.

### Support for Network Protocols

Support for various network protocols can be enabled through [Cargo features listed in the documentation][rustdoc-homepage].
Most of these use `embassy_net`, which should be used through the [`ariel_os::reexports::embassy_net`][embassy-net-reexport-rustdoc] re-export.

### Using the Network Stack

A network stack handle can then be obtained using [`ariel_os::net::network_stack()`][network-stack-rustdoc].

See the [examples][examples-dir-repo] for details.

## Host Setup

### Static IPv4 Address Configuration

When using a device with a static IPv4 address,
the host computer can be configured as follows (where `host_address` is an IP address configured as gateway for the device):

```
# ip address add <host_address>/24 dev <interface>
# ip link set up dev <interface>
```

To verify that the address has indeed be added, you can use:

```sh
ip address show dev <interface>
```

Replace `<interface>` with the name of the used network interface.
To find out the name of your interface you can use a command such as `ip address`.

### Ethernet over USB

For Ethernet over USB, ensure that, in addition to the USB cable used for flashing
and debugging, the *user* USB port is also connected to the host computer with
a second cable.

[ethernet-builtin-mac-book]: ./ethernet.md#using-microcontrollers-with-a-built-in-ethernet-mac
[ethernet-external-mac-book]: ./ethernet.md#using-external-ethernet-mac--phy-chips
[rustdoc-homepage]: https://ariel-os.github.io/ariel-os/dev/docs/api/ariel_os/index.html
[config-attr-macro-rustdoc]: https://ariel-os.github.io/ariel-os/dev/docs/api/ariel_os/attr.config.html
[network-stack-rustdoc]: https://ariel-os.github.io/ariel-os/dev/docs/api/ariel_os/net/fn.network_stack.html
[embassy-net-reexport-rustdoc]: https://ariel-os.github.io/ariel-os/dev/docs/api/ariel_os/reexports/embassy_net/index.html
[examples-dir-repo]: https://github.com/ariel-os/ariel-os/tree/main/examples
[laze-modules-book]: ./build-system.md#laze-modules
[enabling-laze-modules-book]: ./build-system.md#enabling-laze-modules-for-an-application
