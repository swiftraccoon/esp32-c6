// @generated

pub mod pins {
    ariel_os_hal::define_peripherals!(ButtonPeripherals { button0 : GPIO0, });
    ariel_os_hal::define_uarts![
        { name : Uart0, device : UART0, tx : GPIO1, rx : GPIO3, host_facing : true },
    ];
}
#[allow(unused_variables)]
pub fn init(peripherals: &mut ariel_os_hal::hal::OptionalPeripherals) {}
