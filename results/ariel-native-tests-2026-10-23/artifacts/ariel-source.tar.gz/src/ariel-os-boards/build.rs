// @generated

pub fn main() {
    println!(
        "cargo::rustc-check-cfg=cfg(context, values(\"adafruit-feather-nrf52840-express\"))"
    );
    println!(
        "cargo::rustc-check-cfg=cfg(context, values(\"adafruit-feather-nrf52840-sense\"))"
    );
    println!("cargo::rustc-check-cfg=cfg(context, values(\"arduino-uno-q\"))");
    println!("cargo::rustc-check-cfg=cfg(context, values(\"bbc-microbit-v1\"))");
    println!("cargo::rustc-check-cfg=cfg(context, values(\"bbc-microbit-v2\"))");
    println!("cargo::rustc-check-cfg=cfg(context, values(\"decawave-dwm1001-dev\"))");
    println!(
        "cargo::rustc-check-cfg=cfg(context, values(\"dfrobot-firebeetle2-esp32-c6\"))"
    );
    println!(
        "cargo::rustc-check-cfg=cfg(context, values(\"espressif-esp32-c3-devkit-rust-1\"))"
    );
    println!(
        "cargo::rustc-check-cfg=cfg(context, values(\"espressif-esp32-c3-lcdkit\"))"
    );
    println!(
        "cargo::rustc-check-cfg=cfg(context, values(\"espressif-esp32-c6-devkitc-1\"))"
    );
    println!("cargo::rustc-check-cfg=cfg(context, values(\"espressif-esp32-devkitc\"))");
    println!(
        "cargo::rustc-check-cfg=cfg(context, values(\"espressif-esp32-h2-devkitm-1\"))"
    );
    println!(
        "cargo::rustc-check-cfg=cfg(context, values(\"espressif-esp32-s2-devkitc-1\"))"
    );
    println!(
        "cargo::rustc-check-cfg=cfg(context, values(\"espressif-esp32-s3-devkitc-1\"))"
    );
    println!(
        "cargo::rustc-check-cfg=cfg(context, values(\"espressif-esp8684-devkitc-02\"))"
    );
    println!("cargo::rustc-check-cfg=cfg(context, values(\"heltec-wifi-lora-32-v3\"))");
    println!(
        "cargo::rustc-check-cfg=cfg(context, values(\"makerdiary-nrf52840-mdk-usb-dongle\"))"
    );
    println!("cargo::rustc-check-cfg=cfg(context, values(\"makerdiary-nrf52840-mdk\"))");
    println!(
        "cargo::rustc-check-cfg=cfg(context, values(\"makerdiary-nrf9151-connect-kit\"))"
    );
    println!("cargo::rustc-check-cfg=cfg(context, values(\"native\"))");
    println!(
        "cargo::rustc-check-cfg=cfg(context, values(\"nordic-thingy-91-x-nrf9151\"))"
    );
    println!(
        "cargo::rustc-check-cfg=cfg(context, values(\"nordic-thingy-91-x-nrf5340-app\"))"
    );
    println!(
        "cargo::rustc-check-cfg=cfg(context, values(\"nordic-thingy-91-x-nrf5340-net\"))"
    );
    println!("cargo::rustc-check-cfg=cfg(context, values(\"nrf52840dk\"))");
    println!("cargo::rustc-check-cfg=cfg(context, values(\"nrf52dk\"))");
    println!("cargo::rustc-check-cfg=cfg(context, values(\"nrf5340dk-app\"))");
    println!("cargo::rustc-check-cfg=cfg(context, values(\"nrf5340dk-net\"))");
    println!("cargo::rustc-check-cfg=cfg(context, values(\"nrf54l15dk-app\"))");
    println!("cargo::rustc-check-cfg=cfg(context, values(\"nrf9151-dk\"))");
    println!("cargo::rustc-check-cfg=cfg(context, values(\"nrf9160dk-nrf9160\"))");
    println!("cargo::rustc-check-cfg=cfg(context, values(\"particle-xenon\"))");
    println!("cargo::rustc-check-cfg=cfg(context, values(\"rpi-pico-w\"))");
    println!("cargo::rustc-check-cfg=cfg(context, values(\"rpi-pico\"))");
    println!("cargo::rustc-check-cfg=cfg(context, values(\"rpi-pico2-w\"))");
    println!("cargo::rustc-check-cfg=cfg(context, values(\"rpi-pico2\"))");
    println!(
        "cargo::rustc-check-cfg=cfg(context, values(\"seeedstudio-lora-e5-mini\"))"
    );
    println!(
        "cargo::rustc-check-cfg=cfg(context, values(\"seeedstudio-xiao-esp32-s3\"))"
    );
    println!(
        "cargo::rustc-check-cfg=cfg(context, values(\"seeedstudio-xiao-esp32c6\"))"
    );
    println!(
        "cargo::rustc-check-cfg=cfg(context, values(\"seeedstudio-xiao-nrf52840-plus\"))"
    );
    println!("cargo::rustc-check-cfg=cfg(context, values(\"st-b-l072z-lrwan1\"))");
    println!("cargo::rustc-check-cfg=cfg(context, values(\"st-b-l475e-iot01a\"))");
    println!("cargo::rustc-check-cfg=cfg(context, values(\"st-nucleo-c031c6\"))");
    println!("cargo::rustc-check-cfg=cfg(context, values(\"st-nucleo-f042k6\"))");
    println!("cargo::rustc-check-cfg=cfg(context, values(\"st-nucleo-f303re\"))");
    println!("cargo::rustc-check-cfg=cfg(context, values(\"st-nucleo-f401re\"))");
    println!("cargo::rustc-check-cfg=cfg(context, values(\"st-nucleo-f411re\"))");
    println!("cargo::rustc-check-cfg=cfg(context, values(\"st-nucleo-f767zi\"))");
    println!("cargo::rustc-check-cfg=cfg(context, values(\"st-nucleo-g431rb\"))");
    println!("cargo::rustc-check-cfg=cfg(context, values(\"st-nucleo-h753zi\"))");
    println!("cargo::rustc-check-cfg=cfg(context, values(\"st-nucleo-h755zi-q\"))");
    println!("cargo::rustc-check-cfg=cfg(context, values(\"st-nucleo-wb55\"))");
    println!("cargo::rustc-check-cfg=cfg(context, values(\"st-nucleo-wba55\"))");
    println!("cargo::rustc-check-cfg=cfg(context, values(\"st-nucleo-wba65ri\"))");
    println!("cargo::rustc-check-cfg=cfg(context, values(\"st-steval-mkboxpro\"))");
    println!("cargo::rustc-check-cfg=cfg(context, values(\"stm32u083c-dk\"))");
    println!("cargo::rustc-check-cfg=cfg(context, values(\"ulanzi-tc001\"))");
    println!("cargo::rustc-check-cfg=cfg(context, values(\"unihiker-k10\"))");
    println!("cargo::rustc-check-cfg=cfg(context, values(\"waveshare-esp32-s3-eth\"))");
    println!(
        "cargo::rustc-check-cfg=cfg(context, values(\"waveshare-esp32-s3-matrix\"))"
    );
}
