#[cfg(not(context = "nrf54l"))]
use crate::irqs::Irqs;

/// Constructs the hardware random number generator (RNG) for the nRF family.
///
/// # Panics
///
/// Panics if the RNG peripheral has been previously used/taken.
pub fn construct_rng(peripherals: &mut crate::OptionalPeripherals) {
    cfg_select! {
        // The union of all contexts that wind up in a construct_rng should be synchronized
        // with laze-project.yml's hwrng module.
        any(context = "nrf51", context = "nrf52", context = "nrf5340-net") => {
            let p = peripherals
                .RNG
                .take()
                .expect("RNG has not been previously used");

            let mut rng = embassy_nrf::rng::Rng::new(p, Irqs);

            ariel_os_random::construct_rng(&mut ariel_os_random::RngAdapter(&mut rng));
        }
        any(context = "nrf91", context = "nrf5340-app") => {
            let p = peripherals
                .CC_RNG
                .take()
                .expect("CC_RNG has not been previously used");

            let mut cc_rng = embassy_nrf::cryptocell::rng::CcRng::new(p, Irqs);

            ariel_os_random::construct_rng(&mut ariel_os_random::RngAdapter(&mut cc_rng));
        }
        any(context = "nrf54l") => {
            let p = peripherals
                .CRACEN
                .take()
                .expect("CRACEN has not been previously used");

            let mut cracen = embassy_nrf::cracen::Cracen::new_blocking(p);

            ariel_os_random::construct_rng(&mut ariel_os_random::RngAdapter(&mut cracen));
        }
        context = "ariel-os" => {
            compile_error!("hardware RNG is not supported on this MCU family");
        }
    }
}
