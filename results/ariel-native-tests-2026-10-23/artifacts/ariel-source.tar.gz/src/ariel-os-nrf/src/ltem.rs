use embassy_executor::Spawner;
use embassy_net::Stack;
use embassy_sync::{blocking_mutex::raw::CriticalSectionRawMutex, signal::Signal};
use nrf_modem::embassy_net_modem::{
    NetDriver, Runner, State,
    context::{self, AuthProt, PdConfig, PdnAuth, PdpType, Status},
};
use static_cell::StaticCell;

use ariel_os_embassy_common::cellular_networking;
use ariel_os_log::warn;

pub type NetworkDevice = NetDriver<'static>;

// Packet Data Protocol context id, range 0-10. On nrf9160 only cid 0 is already allocated.
const PDP_CONTEXT_ID: u8 = 0;

static LTEM_STATE: StaticCell<State> = StaticCell::new();
static LTEM_CONTROL: StaticCell<context::Control<'static>> = StaticCell::new();

// `context::Control` is not `Send`, we can only interact with it in `control_task()`.
// Using a `Signal` here so we can disable/enable the LTE-M modem from any task/thread.
static CONTROL_SIGNAL: Signal<CriticalSectionRawMutex, Command> = Signal::new();

enum Command {
    Enable,
    Disable,
}

/// Disable the LTE-M link.
///
/// Will be replaced by the new network interface toggle API.
#[doc(hidden)]
pub fn disable() {
    CONTROL_SIGNAL.signal(Command::Disable);
}
/// Enable the LTE-M link.
///
/// Will be replaced by the new network interface toggle API.
#[doc(hidden)]
pub fn enable() {
    CONTROL_SIGNAL.signal(Command::Enable);
}

#[embassy_executor::task]
async fn modem_task(runner: Runner<'static>) -> ! {
    runner.run().await
}

fn convert_cellular_networking_config(
    config: &cellular_networking::PdConfig<'static>,
) -> PdConfig<'static> {
    let apn = config.apn.map(str::as_bytes);
    let pdn_auth = config.pdn_auth.map(|auth_config| {
        let (auth_prot, credentials) = match auth_config {
            cellular_networking::PdnAuthentication::None => (AuthProt::None, None),
            cellular_networking::PdnAuthentication::Pap(creds) => (AuthProt::Pap, Some(creds)),
            cellular_networking::PdnAuthentication::Chap(creds) => (AuthProt::Chap, Some(creds)),
        };

        let auth = credentials.map(|c| (c.username.as_bytes(), c.password.as_bytes()));

        PdnAuth { auth, auth_prot }
    });

    let pdp_type = match config.pdp_type {
        cellular_networking::PdpType::Ip => PdpType::Ip,
        cellular_networking::PdpType::Ipv6 => PdpType::Ipv6,
        cellular_networking::PdpType::Ipv4v6 => PdpType::Ipv4v6,
        cellular_networking::PdpType::NonIp => PdpType::NonIp,
    };

    PdConfig {
        apn,
        pdn_auth,
        pdp_type,
    }
}

/// Task responsible of maintaining the connection status up to date.
/// Also configures the modem when starting (if a `config` is provided)
///
/// # Panics
///
/// When the configuration is invalid.
#[embassy_executor::task]
pub async fn control_task(
    control: &'static context::Control<'static>,
    config: cellular_networking::PdConfig<'static>,
    pin: Option<&'static str>,
    stack: Stack<'static>,
) {
    control
        .configure(
            &convert_cellular_networking_config(&config),
            pin.map(str::as_bytes),
        )
        .await
        .unwrap();

    embassy_futures::join::join(
        async {
            loop {
                let err = match CONTROL_SIGNAL.wait().await {
                    Command::Disable => control.disable().await,
                    Command::Enable => control.enable().await,
                };
                if let Err(_err) = err {
                    warn!("Error when processing command: {}", _err);
                }
            }
        },
        control.run(|status| {
            let config = status_to_config(status);

            #[cfg(feature = "ipv4")]
            stack.set_config_v4(config.ipv4);

            #[cfg(feature = "ipv6")]
            stack.set_config_v6(config.ipv6);
        }),
    )
    .await;
}

fn can_contain<TContained, TContainer, const N_CONTAINED: usize, const N_CONTAINER: usize>(
    _: &heapless::Vec<TContained, N_CONTAINED>,
) -> heapless::Vec<TContainer, N_CONTAINER> {
    const {
        assert!(
            N_CONTAINER >= N_CONTAINED,
            "embassy config cannot contain the maximum number of DNS servers"
        );
    };
    heapless::vec::Vec::new()
}

/// Creates an embassy-net config from a modem status update.
#[must_use]
fn status_to_config(status: &Status) -> embassy_net::Config {
    let mut config = embassy_net::Config::default();

    #[cfg(feature = "ipv4")]
    if let Some(ref link) = status.ipv4_link {
        // We make sure `dns_servers` has a capacity superior or equal to the one of link.dns
        let mut dns_servers = can_contain(&link.dns);
        dns_servers.extend(link.dns.iter().copied());
        config.ipv4 = embassy_net::ConfigV4::Static(embassy_net::StaticConfigV4 {
            // This is a point to point connection, the modem never gives a subnet mask.
            // `local_addr_and_subnet_mask` is not supported by the AT command +CGCONTRDP.
            // In the nRF SDK no mask is used. A /32 CIDR is the best equivalent to a
            // Zephyr NET_ADDR_MANUAL with no set mask.
            address: embassy_net::Ipv4Cidr::new(link.ip, 32),
            dns_servers,
            gateway: link.gateway,
        });
    } else {
        warn!("No ipv4 config found");
    }

    #[cfg(feature = "ipv6")]
    if let Some(ref link) = status.ipv6_link {
        // We make sure `dns_servers` has a capacity superior or equal to the one of link.dns
        let mut dns_servers = can_contain(&link.dns);
        dns_servers.extend(link.dns.iter().copied());
        config.ipv6 = embassy_net::ConfigV6::Static(embassy_net::StaticConfigV6 {
            // This is a point to point connection, the modem never gives a subnet mask,
            // `local_addr_and_subnet_mask` is not supported by the AT command +CGCONTRDP.
            // In the nRF SDK no mask is used. A /128 CIDR is the best equivalent to a
            // Zephyr NET_ADDR_MANUAL with no set mask.
            address: embassy_net::Ipv6Cidr::new(link.ip, 128),
            dns_servers,
            gateway: link.gateway,
        });
    } else {
        warn!("No ipv6 config found");
    }

    config
}

/// Initializes the modem for LTE-M networking.
/// The control task needs to be spawned using [`control_task`].
///
/// # Panics
///
/// When called more than once (because it spawns a task that does not terminate).
#[must_use]
pub async fn init<'a>(spawner: Spawner) -> (NetworkDevice, &'a context::Control<'a>) {
    let (driver, control, runner) =
        nrf_modem::embassy_net_modem::new(LTEM_STATE.init(State::new())).await;

    spawner.spawn(modem_task(runner).unwrap());

    let control = LTEM_CONTROL.init(context::Control::new(control, PDP_CONTEXT_ID).await);

    (driver, control)
}
