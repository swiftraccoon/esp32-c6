//! Provides support for the I2C communication bus in controller mode.

#![expect(unsafe_code)]

use portable_atomic::{AtomicBool, Ordering};

use ariel_os_embassy_common::impl_async_i2c_for_driver_enum;

use embassy_nrf::{
    bind_interrupts,
    gpio::Pin as GpioPin,
    peripherals,
    twim::{InterruptHandler, Twim},
};

use static_cell::ConstStaticCell;

/// I2C bus configuration.
#[non_exhaustive]
#[expect(clippy::struct_excessive_bools)]
#[derive(Clone)]
pub struct Config {
    /// The frequency at which the bus should operate.
    pub frequency: Frequency,
    /// Whether to enable the internal pull-up resistor on the SDA pin.
    pub sda_pullup: bool,
    /// Whether to enable the internal pull-up resistor on the SCL pin.
    pub scl_pullup: bool,
    /// Whether to set the SDA pin's drive strength to
    /// [`DriveStrength::High`](crate::gpio::DriveStrength::High).
    pub sda_high_drive: bool,
    /// Whether to set the SCL pin's drive strength to
    /// [`DriveStrength::High`](crate::gpio::DriveStrength::High).
    pub scl_high_drive: bool,
}

impl Default for Config {
    fn default() -> Self {
        Self {
            frequency: Frequency::_100k,
            sda_pullup: false,
            scl_pullup: false,
            sda_high_drive: false,
            scl_high_drive: false,
        }
    }
}

/// I2C bus frequency.
// NOTE(hal): the datasheets only mention these frequencies.
#[cfg(any(
    context = "nrf52833",
    context = "nrf52840",
    context = "nrf5340-app",
    context = "nrf91"
))]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
#[cfg_attr(feature = "defmt", derive(defmt::Format))]
pub enum Frequency {
    /// Standard mode.
    _100k,
    /// 250 kHz.
    #[cfg(any(context = "nrf52833", context = "nrf5340-app", context = "nrf91"))]
    _250k,
    /// Fast mode.
    _400k,
    // FIXME(embassy): the upstream Embassy crate does not support this frequency
    // #[cfg(context = "nrf5340-app", context = "nrf91")]
    // _1M,
}

#[doc(hidden)]
impl Frequency {
    #[must_use]
    pub const fn first() -> Self {
        Self::_100k
    }

    #[must_use]
    pub const fn last() -> Self {
        Self::_400k
    }

    #[must_use]
    pub const fn next(self) -> Option<Self> {
        match self {
            #[cfg(context = "nrf52840")]
            Self::_100k => Some(Self::_400k),
            #[cfg(any(context = "nrf52833", context = "nrf5340-app", context = "nrf91"))]
            Self::_100k => Some(Self::_250k),
            #[cfg(any(context = "nrf52833", context = "nrf5340-app", context = "nrf91"))]
            Self::_250k => Some(Self::_400k),
            Self::_400k => None,
        }
    }

    #[must_use]
    pub const fn prev(self) -> Option<Self> {
        match self {
            Self::_100k => None,
            #[cfg(any(context = "nrf52833", context = "nrf5340-app", context = "nrf91"))]
            Self::_250k => Some(Self::_100k),
            #[cfg(context = "nrf52840")]
            Self::_400k => Some(Self::_100k),
            #[cfg(any(context = "nrf52833", context = "nrf5340-app", context = "nrf91"))]
            Self::_400k => Some(Self::_250k),
        }
    }

    #[must_use]
    pub const fn khz(self) -> u32 {
        match self {
            Self::_100k => 100,
            #[cfg(any(context = "nrf52833", context = "nrf5340-app", context = "nrf91"))]
            Self::_250k => 250,
            Self::_400k => 400,
        }
    }
}

ariel_os_embassy_common::impl_i2c_from_frequency!();

impl From<Frequency> for embassy_nrf::twim::Frequency {
    fn from(freq: Frequency) -> Self {
        match freq {
            Frequency::_100k => embassy_nrf::twim::Frequency::K100,
            #[cfg(any(context = "nrf52833", context = "nrf5340-app", context = "nrf91"))]
            Frequency::_250k => embassy_nrf::twim::Frequency::K250,
            Frequency::_400k => embassy_nrf::twim::Frequency::K400,
        }
    }
}

macro_rules! define_i2c_drivers {
    ($( $interrupt:ident => $peripheral:ident ),* $(,)?) => {
        $(
            /// Peripheral-specific I2C driver.
            pub struct $peripheral {
                twim: Twim<'static>,
            }

            // Ensure this peripheral has only one active Instance.
            paste::paste! {
                static [< ACTIVE_ $peripheral >]: AtomicBool = AtomicBool::new(false);
            }

            impl $peripheral {
                /// Returns a driver implementing [`embedded_hal_async::i2c::I2c`] for this
                /// I2C peripheral.
                #[expect(clippy::new_ret_no_self)]
                #[must_use]
                pub fn new<SDA: GpioPin, SCL: GpioPin>(
                    sda_pin: impl $crate::IntoPeripheral<'static, SDA>,
                    scl_pin: impl $crate::IntoPeripheral<'static, SCL>,
                    config: Config,
                ) -> I2c {
                    let mut twim_config = embassy_nrf::twim::Config::default();
                    twim_config.frequency = config.frequency.into();
                    twim_config.sda_pullup = config.sda_pullup;
                    twim_config.scl_pullup = config.scl_pullup;
                    twim_config.sda_high_drive = config.sda_high_drive;
                    twim_config.scl_high_drive = config.scl_high_drive;

                    bind_interrupts!(
                        struct Irqs {
                            $interrupt => InterruptHandler<peripherals::$peripheral>;
                        }
                    );

                    // Make this struct a compile-time-enforced singleton: having multiple statics
                    // defined with the same name would result in a compile-time error.
                    paste::paste! {
                        #[allow(dead_code)]
                        static [<PREVENT_MULTIPLE_ $peripheral>]: () = ();
                    }

                    // Check if we can initialize this peripheral (check if the value was previously false, set it to true).
                    paste::paste! {
                        if [< ACTIVE_ $peripheral >].swap(true, Ordering::AcqRel) {
                            panic!("I2C peripheral already initialized")
                        }
                    }

                    // FIXME(safety): enforce that the init code indeed has run
                    // SAFETY: We check with an AtomicBool that only one instance of this peripheral
                    // is active at once.
                    let twim_peripheral = unsafe { peripherals::$peripheral::steal() };

                    // NOTE(hal): the I2C implementation for nrf needs a buffer, define it here.
                    // TODO: which size? make configurable
                    paste::paste! {
                        static [<RAM_BUFFER_ $peripheral>]: ConstStaticCell<[u8; 16]> = ConstStaticCell::new([0; 16]);
                    }

                    // NOTE(hal): the I2C peripheral and driver do not have any built-in timeout,
                    // we implement it at a higher level, not in this HAL-specific module.
                    paste::paste! {
                        let twim = Twim::new(
                            twim_peripheral,
                            Irqs,
                            sda_pin.into_hal_peripheral(),
                            scl_pin.into_hal_peripheral(),
                            twim_config,
                            [<RAM_BUFFER_ $peripheral>].take(),
                        );
                    }

                    I2c::$peripheral(Self { twim })
                }
            }

            impl Drop for $peripheral {
                fn drop(&mut self) {
                    paste::paste! {
                        [< ACTIVE_ $peripheral >].store(false, Ordering::Release);
                    }
                }
            }
        )*

        /// Peripheral-agnostic driver.
        pub enum I2c {
            $(
                #[doc = concat!(stringify!($peripheral), " peripheral.")]
                $peripheral($peripheral),
            )*
        }

        impl embedded_hal_async::i2c::ErrorType for I2c {
            type Error = ariel_os_embassy_common::i2c::controller::Error;
        }

        impl_async_i2c_for_driver_enum!(I2c, $( $peripheral ),*);
    }
}

// We cannot impl From because both types are external to this crate.
fn from_error(err: embassy_nrf::twim::Error) -> ariel_os_embassy_common::i2c::controller::Error {
    use embassy_nrf::twim::Error::{
        AddressNack, DataNack, Overrun, RAMBufferTooSmall, Receive, RxBufferTooLong, Timeout,
        Transmit, TxBufferTooLong,
    };

    use ariel_os_embassy_common::i2c::controller::{Error, NoAcknowledgeSource};

    #[expect(clippy::match_same_arms, reason = "non-exhaustive upstream enum")]
    match err {
        TxBufferTooLong | RxBufferTooLong | Transmit | Receive | RAMBufferTooSmall => Error::Other,
        AddressNack => Error::NoAcknowledge(NoAcknowledgeSource::Address),
        DataNack => Error::NoAcknowledge(NoAcknowledgeSource::Data),
        Overrun => Error::Overrun,
        Timeout => Error::Timeout,
        _ => Error::Other,
    }
}

// FIXME: support other nRF archs
// Define a driver per peripheral
#[cfg(any(context = "nrf52833", context = "nrf52840"))]
define_i2c_drivers!(
    TWISPI0 => TWISPI0,
    TWISPI1 => TWISPI1,
);
#[cfg(context = "nrf5340-app")]
define_i2c_drivers!(
    SERIAL0 => SERIAL0,
    SERIAL1 => SERIAL1,
);
#[cfg(context = "nrf91")]
define_i2c_drivers!(
    SERIAL0 => SERIAL0,
    SERIAL1 => SERIAL1,
);
