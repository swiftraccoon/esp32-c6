//! Provides support for the I2C communication bus in controller mode.

#![expect(unsafe_code)]

use portable_atomic::{AtomicBool, Ordering};

use ariel_os_embassy_common::impl_async_i2c_for_driver_enum;
use esp_hal::{
    Async,
    gpio::interconnect::{PeripheralInput, PeripheralOutput},
    i2c::master::{BusTimeout, I2c as EspI2c},
    peripherals,
};

/// I2C bus configuration.
#[non_exhaustive]
#[derive(Clone)]
pub struct Config {
    /// The frequency at which the bus should operate.
    pub frequency: Frequency,
}

impl Default for Config {
    fn default() -> Self {
        Self {
            frequency: Frequency::_100k,
        }
    }
}

/// I2C bus frequency.
// NOTE(hal): the technical references only mention these frequencies.
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
#[cfg_attr(feature = "defmt", derive(defmt::Format))]
pub enum Frequency {
    /// Standard mode.
    _100k,
    /// Fast mode.
    _400k,
}

#[doc(hidden)]
impl Frequency {
    #[must_use]
    pub const fn first() -> Self {
        Self::_100k
    }

    #[must_use]
    pub const fn last() -> Self {
        Self::_400k
    }

    #[must_use]
    pub const fn next(self) -> Option<Self> {
        match self {
            Self::_100k => Some(Self::_400k),
            Self::_400k => None,
        }
    }

    #[must_use]
    pub const fn prev(self) -> Option<Self> {
        match self {
            Self::_100k => None,
            Self::_400k => Some(Self::_100k),
        }
    }

    #[must_use]
    pub const fn khz(self) -> u32 {
        match self {
            Self::_100k => 100,
            Self::_400k => 400,
        }
    }
}

ariel_os_embassy_common::impl_i2c_from_frequency!();

impl From<Frequency> for esp_hal::time::Rate {
    fn from(freq: Frequency) -> Self {
        match freq {
            Frequency::_100k => esp_hal::time::Rate::from_khz(100),
            Frequency::_400k => esp_hal::time::Rate::from_khz(400),
        }
    }
}

macro_rules! define_i2c_drivers {
    ($( $peripheral:ident ),* $(,)?) => {
        $(
            /// Peripheral-specific I2C driver.
            pub struct $peripheral {
                twim: EspI2c<'static, Async>,
            }

            // Ensure this peripheral has only one active Instance.
            paste::paste! {
                static [< ACTIVE_ $peripheral >]: AtomicBool = AtomicBool::new(false);
            }

            impl $peripheral {
                /// Returns a driver implementing [`embedded_hal_async::i2c::I2c`] for this
                /// I2C peripheral.
                #[expect(clippy::new_ret_no_self)]
                #[must_use]
                pub fn new<SDA: PeripheralInput<'static> + PeripheralOutput<'static>, SCL: PeripheralInput<'static> + PeripheralOutput<'static>>(
                    sda_pin: impl $crate::IntoPeripheral<'static, SDA>,
                    scl_pin: impl $crate::IntoPeripheral<'static, SCL>,
                    config: Config,
                ) -> I2c {
                    // Make this struct a compile-time-enforced singleton: having multiple statics
                    // defined with the same name would result in a compile-time error.
                    paste::paste! {
                        #[allow(dead_code)]
                        static [<PREVENT_MULTIPLE_ $peripheral>]: () = ();
                    }

                    let twim_config = esp_hal::i2c::master::Config::default()
                        .with_frequency(config.frequency.into())
                        // disable timeout as we handle that at a higher level.
                        .with_timeout(
                            #[cfg(not(context = "esp32"))]
                            BusTimeout::Disabled,
                            // Use the maximum value as timeout cannot be disabled.
                            #[cfg(context = "esp32")]
                            BusTimeout::Maximum
                            );

                    // Check if we can initialize this peripheral (check if the value was previously false, set it to true).
                    paste::paste! {
                        if [< ACTIVE_ $peripheral >].swap(true, Ordering::AcqRel) {
                            panic!("I2C peripheral already initialized")
                        }
                    }

                    // FIXME(safety): enforce that the init code indeed has run
                    // SAFETY: We check with an AtomicBool that only one instance of this peripheral
                    // is active at once.
                    let i2c_peripheral = unsafe { peripherals::$peripheral::steal() };

                    let twim = EspI2c::new(
                        i2c_peripheral,
                        twim_config,
                    )
                        .unwrap()
                        .into_async()
                        .with_sda(sda_pin.into_hal_peripheral())
                        .with_scl(scl_pin.into_hal_peripheral());

                    I2c::$peripheral(Self { twim })
                }
            }

            impl Drop for $peripheral {
                fn drop(&mut self) {
                    paste::paste! {
                        [< ACTIVE_ $peripheral >].store(false, Ordering::Release);
                    }
                }
            }
        )*

        /// Peripheral-agnostic driver.
        pub enum I2c {
            $(
                #[doc = concat!(stringify!($peripheral), " peripheral.")]
                $peripheral($peripheral),
            )*
        }

        impl embedded_hal_async::i2c::ErrorType for I2c {
            type Error = ariel_os_embassy_common::i2c::controller::Error;
        }

        impl_async_i2c_for_driver_enum!(I2c, $( $peripheral ),*);
    }
}

// We cannot impl From because both types are external to this crate.
fn from_error(err: esp_hal::i2c::master::Error) -> ariel_os_embassy_common::i2c::controller::Error {
    use esp_hal::i2c::master::{AcknowledgeCheckFailedReason, Error as EspError};

    use ariel_os_embassy_common::i2c::controller::{Error, NoAcknowledgeSource};

    #[expect(clippy::match_same_arms, reason = "non-exhaustive upstream enum")]
    match err {
        EspError::FifoExceeded => Error::Overrun,
        EspError::AcknowledgeCheckFailed(reason) => {
            let reason = match reason {
                AcknowledgeCheckFailedReason::Address => NoAcknowledgeSource::Address,
                AcknowledgeCheckFailedReason::Data => NoAcknowledgeSource::Data,
                AcknowledgeCheckFailedReason::Unknown | _ => NoAcknowledgeSource::Unknown,
            };
            Error::NoAcknowledge(reason)
        }
        EspError::Timeout => Error::Timeout,
        EspError::ArbitrationLost => Error::ArbitrationLoss,
        EspError::ExecutionIncomplete
        | EspError::CommandNumberExceeded
        | EspError::ZeroLengthInvalid => Error::Other,
        _ => Error::Other,
    }
}

// Define a driver per peripheral
#[cfg(context = "esp32")]
define_i2c_drivers!(I2C0, I2C1);
#[cfg(context = "esp32c2")]
define_i2c_drivers!(I2C0);
#[cfg(context = "esp32c3")]
define_i2c_drivers!(I2C0);
#[cfg(context = "esp32c6")]
define_i2c_drivers!(I2C0);
#[cfg(context = "esp32h2")]
define_i2c_drivers!(I2C0, I2C1);
#[cfg(context = "esp32s2")]
define_i2c_drivers!(I2C0, I2C1);
#[cfg(context = "esp32s3")]
define_i2c_drivers!(I2C0, I2C1);
