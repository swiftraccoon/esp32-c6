//! Provides runtime helpers.

#![cfg_attr(not(any(test, context = "native")), no_std)]
#![cfg_attr(test, no_main)]
#![deny(missing_docs)]
#![allow(incomplete_features)]
#![allow(unsafe_code)]
#![cfg_attr(context = "xtensa", feature(asm_experimental_arch))]

pub mod stack;

#[cfg(feature = "threading")]
mod threading;

#[cfg(all(feature = "single-core", feature = "multi-core"))]
compile_error!(
    "feature \"single-core\" and feature \"multi-core\" cannot be enabled at the same time"
);

#[cfg(all(feature = "memory-x", context = "ariel-os"))]
#[allow(missing_docs)]
pub mod memory {
    pub mod sections {
        include!(concat!(env!("OUT_DIR"), "/linker_sections.rs"));
    }
}

use ariel_os_log::debug;

cfg_select! {
    context = "cortex-m" => {
        mod cortexm;
        use cortexm as arch;
    }
    context = "xtensa" => {
        mod xtensa;
        use xtensa as arch;
    }
    context = "riscv" => {
        mod riscv;
        use riscv as arch;
    }
    context = "native" => {
        mod native;
        use native as arch;
    }
    context = "ariel-os" => {
        // When run with laze but the MCU family is not supported
        compile_error!("no runtime is defined for this MCU family");
    }
    _ => {
        // Provide a default implementation, for arch-independent tooling
        #[cfg_attr(not(context = "ariel-os"), allow(dead_code))]
        mod arch {
            use crate::stack::Stack;

            pub fn init() {}
            pub fn wfi() {}
            pub fn sp() -> usize {
                0
            }
            pub fn stack() -> Stack {
                Stack::default()
            }
        }
    }
}

#[cfg(any(context = "cortex-m", context = "riscv", context = "xtensa"))]
mod isr_stack {
    #[cfg(not(context = "xtensa"))]
    pub(crate) const ISR_STACKSIZE: usize = {
        const CONFIG_ISR_STACKSIZE: usize = ariel_os_utils::usize_from_env_or!(
            "CONFIG_ISR_STACKSIZE",
            2048,
            "ISR stack size (in bytes)"
        );

        #[cfg(feature = "executor-interrupt")]
        {
            const CONFIG_EXECUTOR_STACKSIZE: usize = ariel_os_utils::usize_from_env_or!(
                "CONFIG_EXECUTOR_STACKSIZE",
                8192,
                "System executor stack size (in bytes)"
            );

            CONFIG_ISR_STACKSIZE + CONFIG_EXECUTOR_STACKSIZE
        }

        #[cfg(not(feature = "executor-interrupt"))]
        CONFIG_ISR_STACKSIZE
    };

    #[cfg(not(context = "xtensa"))]
    core::arch::global_asm!(
        r#"
        .section .isr_stack, "wa"
        .skip {size}
        "#,
        size = const ISR_STACKSIZE
    );

    pub fn limits() -> (usize, usize) {
        #[cfg(not(feature = "multi-core"))]
        {
            crate::isr_stack::limits_core0()
        }

        #[cfg(feature = "multi-core")]
        {
            use ariel_os_threads::{CoreId, core_id};
            if core_id() == CoreId::new(0) {
                crate::isr_stack::limits_core0()
            } else {
                crate::isr_stack::limits_core1()
            }
        }
    }

    pub fn limits_core0() -> (usize, usize) {
        // ISR stack for core0 is defined via linker script.
        unsafe extern "C" {
            static _stack_lowest: u32;
            static _stack_highest: u32;
        }

        let lowest = &raw const _stack_lowest as usize;
        let highest = &raw const _stack_highest as usize;
        (lowest, highest)
    }

    #[cfg(feature = "multi-core")]
    pub fn limits_core1() -> (usize, usize) {
        // ISR stack for core1 is exported from the threading module.
        ariel_os_threads::isr_stack_core1_get_limits()
    }

    pub fn init() {
        let stack = crate::stack::Stack::get();
        crate::debug!("ariel-os-rt: ISR stacksize: {}", stack.size());

        // initial stack paint
        stack.repaint();
    }
}

#[cfg(all(
    feature = "_panic-handler",
    any(context = "esp", context = "nrf", context = "rp", context = "stm32"),
))]
#[panic_handler]
fn panic(_info: &core::panic::PanicInfo<'_>) -> ! {
    #[cfg(feature = "panic-printing")]
    ariel_os_log::print_panic(_info);

    ariel_os_debug::exit(ariel_os_debug::ExitCode::FAILURE);

    #[allow(clippy::empty_loop)]
    loop {}
}

use linkme::distributed_slice;

#[doc(hidden)]
#[distributed_slice]
pub static INIT_FUNCS: [fn()] = [..];

#[inline]
#[cfg_attr(not(context = "ariel-os"), allow(dead_code))]
fn startup() -> ! {
    arch::init();

    #[cfg(feature = "debug-channel")]
    ariel_os_debug::init();

    ariel_os_log::init();

    debug!("ariel_os_rt::startup()");

    #[cfg(any(context = "cortex-m", context = "riscv", context = "xtensa"))]
    crate::isr_stack::init();

    #[cfg(feature = "alloc")]
    // SAFETY: *this* is the only place alloc should be initialized.
    unsafe {
        ariel_os_alloc::init();
    }

    #[cfg(test)]
    debug!("ariel_os_rt::startup() cfg(test)");

    for f in INIT_FUNCS {
        f();
    }

    #[cfg(feature = "threading")]
    {
        // SAFETY: this function must not be called more than once
        unsafe {
            threading::start();
        }
    }

    #[cfg(not(feature = "threading"))]
    {
        #[cfg(test)]
        test_main();

        loop {
            arch::wfi();
        }
    }
}

#[cfg(feature = "embedded-test")]
#[ariel_os_macros::thread(autostart, stacksize = 16384)]
fn embedded_test_thread() {
    // TODO: make stack size configurable
    unsafe { embedded_test::export::__embedded_test_entry() }
}
