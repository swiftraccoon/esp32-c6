#![expect(unsafe_code)]

use crate::stack::Stack;

#[esp_hal::main]
fn main() -> ! {
    crate::startup();
}

pub fn init() {}

#[allow(dead_code, reason = "conditional compilation")]
pub fn wfi() {
    // The options are similar to those used for wfi on RISC-V and Cortex-M:
    // the instruction does not modify memory or the stack, and does preserve flags.
    // SAFETY: executing `waiti 0` is sound.
    unsafe {
        core::arch::asm!("waiti 0", options(nomem, nostack, preserves_flags));
    }
}

/// Returns the current stack pointer register value
pub(crate) fn sp() -> usize {
    let sp: usize;
    // Safety: reading SP is safe
    unsafe {
        core::arch::asm!(
            "mov {}, sp",
            out(reg) sp,
            options(nomem, nostack, preserves_flags)
        )
    };
    sp
}

/// Returns a `Stack` handle for the currently active thread.
pub(crate) fn stack() -> Stack {
    #[cfg(feature = "threading")]
    let (lowest, highest) = {
        let (lowest, highest) = crate::isr_stack::limits();
        let sp = sp();
        if !(lowest <= sp && highest >= sp) {
            ariel_os_threads::current_stack_limits().unwrap()
        } else {
            (lowest, highest)
        }
    };

    // When threading is disabled, the isr stack is used.
    #[cfg(not(feature = "threading"))]
    let (lowest, highest) = crate::isr_stack::limits();

    Stack::new(lowest, highest)
}
