#![allow(unused, reason = "used by documentation only")]

use embassy_executor::SpawnToken;

#[doc(hidden)]
pub struct Executor;

impl Executor {
    #[allow(clippy::new_without_default)]
    #[must_use]
    pub const fn new() -> Self {
        // Actually return a value instead of marking it unimplemented like other dummy
        // functions, because this function is const and is thus run during compilation
        Self {}
    }

    pub fn start(&self, _: crate::hal::SWI) {
        unimplemented!();
    }

    #[must_use]
    pub fn spawner(&self) -> Spawner {
        unimplemented!();
    }
}

#[doc(hidden)]
pub struct Spawner;

impl Spawner {
    pub fn spawn<S>(&self, _token: SpawnToken<S>) {
        unimplemented!();
    }
}
