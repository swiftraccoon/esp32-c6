//! Provides MCU-specific items.
//!
//! This module dispatches between one of the following crate, depending on the target MCU family:
//!
//! | Manufacturer         | MCU family  | Docs rendered for | Items imported                                       |
//! | -------------------- | ----------- | ----------------- | ---------------------------------------------------- |
//! | Espressif            | ESP32       | ESP32-C6          | [`ariel-os-esp::*`](../../ariel_os_esp/index.html)     |
//! | Nordic Semiconductor | nRF         | nRF52840          | [`ariel-os-nrf::*`](../../ariel_os_nrf/index.html)     |
//! | Raspberry Pi         | RP          | RP2040            | [`ariel-os-rp::*`](../../ariel_os_rp/index.html)       |
//! | STMicroelectronics   | STM32       | STM32WB55RG       | [`ariel-os-stm32::*`](../../ariel_os_stm32/index.html) |
//!
//! Documentation is only rendered for the MCUs listed in the table above, but [many others are
//! supported](https://ariel-os.github.io/ariel-os/dev/docs/book/hardware-functionality-support.html).
//! To render the docs locally for the MCU of your choice, adapt [the `cargo doc` command used to
//! generate documentation for the relevant
//! crate](https://github.com/ariel-os/ariel-os/blob/main/.github/workflows/build-deploy-docs.yml).
//!
//! # Portability
//!
//! To ensure portability of your application, it is recommended to use the generic,
//! MCU-family-agnostic items provided in other modules.
//! Items from this module should only be used when MCU-specific settings are *necessary* for your
//! application.

#[macro_use]
#[doc(hidden)]
pub mod define_peripherals;

// these macros need explicit export from crate root in order to re-export them.
pub use crate::define_peripherals;
pub use crate::define_uart;
pub use crate::define_uarts;
pub use crate::group_peripherals;

pub use define_peripherals::*;

cfg_select! {
    context = "native" => {
        mod dummy;
        pub use ariel_os_native::*;
        pub use dummy::{gpio, peripheral, peripheral::IntoPeripheral};
    }
    context = "nrf" => {
        pub use ariel_os_nrf::*;
    }
    context = "rp" => {
        pub use ariel_os_rp::*;
    }
    context = "esp" => {
        pub use ariel_os_esp::*;
    }
    context = "stm32" => {
        pub use ariel_os_stm32::*;
    }
    context = "ariel-os" => {
        compile_error!("this MCU family is not supported");
    }
    _ => {
        mod dummy;
        pub use dummy::*;
    }
}
