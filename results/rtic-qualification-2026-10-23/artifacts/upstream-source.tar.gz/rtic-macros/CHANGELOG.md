# Change Log

All notable changes to this project will be documented in this file.
This project adheres to [Semantic Versioning](http://semver.org/).

For each category, *Added*, *Changed*, *Fixed* add new entries at the top!

## [Unreleased]

## [v2.4.0] - 2026-10-21

### Changed

- Each async software task's executor is declared as a `static` instead of a `ManuallyDrop` local in `main`.
- Dropped `check_stack_overflow_before_init` from the backend API, and `executors_size` from `init`'s context.

### Fixed

- `RTIC_ASYNC_MAX_LOGICAL_PRIO` is above the highest software task when the device allows it, so monotonics can preempt a blocking software task (#1246).
- Fix `spawn` race with preempting tasks, see #1013
- Removed an occurence of the `needless_late_init` clippy lint.

## [v2.3.1] - 2026-08-20

### Changed

- Add missing docs to `LocalSpawner` struct
- Removed explicit `riscv-slic` feature (this was only used to activate functionality shared between `riscv-clint` and `riscv-mecall`).
- Selecting no or more than one implementation now fails in the build script instead of during compilation.
- `local_task` arguments can be patterns instead of just an ident.
- The `local_task = true` argument to `#[task]` must no longer be the last argument.

### Fixed

- Previously, non-diverging `extern "Rust"` tasks could have a `Context` with a `<'static>` lifetime. This is no longer allowed.

## [v2.3.0] - 2026-07-08

### Fixed

- Remove unused `proc-macro-error2`, now also unmaintained
- Fixed `#[cfg]` tags on hardware and software tasks.
- Generated `panic`s can no longer be shadowed. Previously, they were inconsistently shadowed.
- Generated mutexes for shared resourses no longer implement `Send`. They are meant to be used inside a task locally.
- Consider task-local external resources when identifying which resources must be `Send`.

### Added

- Outer attributes applied to RTIC app module are now forwarded to the generated code.
- Add attribute `local_task` for tasks that may take args that are !Send/!Sync and can only be spawned from same executor

## [v2.2.0] - 2025-06-22

### Added

- Added `waker` getter to software tasks

### Fixed

- Support Rust edition 2024 `unsafe(link_section)` attribute

## [v2.1.3] - 2025-06-08

### Changed 

- Unstable support for ESP32-C6
- Adapt `slic` backends to new version with `mecall`
- Allow software tasks to be diverging (return `!`) and give them `'static` context.

## [v2.1.1 & v2.1.2] - 2024-12-06

### Changed

- Replace `proc-macro-error` with `proc-macro-error2`
- Fix codegen emitting unqualified `Result`
- Improve error output for prios > dispatchers

### Fixed

- Fix interrupt handlers when targeting esp32c3 and using latest version of esp-hal
- Do not limit async priority with `NVIC_PRIO_BITS` when targeting esp32c3

## [v2.1.0] - 2024-02-27

### Added

- Unstable support for RISC-V targets compatible with `riscv-slic`
- RTIC v2 now works on stable.
- Unstable ESP32-C3 support.

### Changed

- Upgraded from syn 1.x to syn 2.x

## [v2.0.1] - 2023-07-25

### Added

- `init` and `idle` can now be externed.

### Fixed

- Support new TAIT syntax requirement.

## [v2.0.0] - 2023-05-31

- Initial v2 release
