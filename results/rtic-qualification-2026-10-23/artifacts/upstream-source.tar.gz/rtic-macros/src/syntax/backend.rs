#[cfg(any(feature = "cortex-m-source-masking", feature = "cortex-m-basepri"))]
pub use cortex::*;

#[cfg(feature = "test-template")]
pub use template::*;

#[cfg(feature = "riscv-esp32c3")]
pub use esp32c3::*;

#[cfg(feature = "riscv-esp32c6")]
pub use esp32c6::*;

#[cfg(riscv_slic)]
pub use riscv_slic::*;

#[cfg(any(feature = "cortex-m-source-masking", feature = "cortex-m-basepri"))]
mod cortex;

#[cfg(feature = "test-template")]
mod template;

#[cfg(feature = "riscv-esp32c3")]
mod esp32c3;

#[cfg(feature = "riscv-esp32c6")]
mod esp32c6;

#[cfg(riscv_slic)]
mod riscv_slic;
