# Change Log

All notable changes to this project will be documented in this file.
This project adheres to [Semantic Versioning](http://semver.org/).

For each category, *Added*, *Changed*, *Fixed* add new entries at the top!

## [Unreleased]

## v1.2.0 - 2026-10-21

### Changed

- Removed `testing` feature

## v1.1.0 - 2025-06-22

- Fix minor unsoundnes in `Link::remove_from_list`.

### Added

- New safe `WaitQueue::wait_until` method.

### Changed

### Fixed

## [v1.0.1]

- `portable-atomic` used as a drop in replacement for `core::sync::atomic` in code and macros. `portable-atomic` imported with `default-features = false`, as we do not require CAS.

## [v1.0.0] - 2023-05-31
