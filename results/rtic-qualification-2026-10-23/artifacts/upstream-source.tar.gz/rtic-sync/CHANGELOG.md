# Change Log

All notable changes to this project will be documented in this file.
This project adheres to [Semantic Versioning](http://semver.org/).

For each category, _Added_, _Changed_, _Fixed_ add new entries at the top!

## Unreleased

## v1.6.0 - 2026-10-21

### Fixed

- A `Channel<T>` is safely `Send` and `Sync` when `T: Send`.
- An `Arbiter<T>` is safely `Send` and `Sync` when `T: Send`.
- `Signal<T>` and `Watch<T>` are safely `Send` and `Sync` when `T: Send`.
- Fixed a bug where, in an unlikely edge-case, `WatchReader::changed` could return twice for a single `WatchWriter::write`.

### Added

- One can now obtain `Reader`s and `Writer`s for a `Watch` and `Signal` individually (i.e. without calling `split()`), and if a `Reader` is dropped it may be recreated.

### Changed

- Removed `testing` feature

## v1.5.0 - 2026-05-30

### Added

- Add `Watch`. Similar to `Signal` but always returns latest value once initialized. Value never evicted.

### Fixed

- Fix a correctness bug that allowed a `Signal` to be split more than once.
- The `panic` in `make_channel` can no longer be shadowed.
- Const check for `channel::Channel` size smaller than 256 is now properly evaluated.

### Changed

- Un-hide lifetimes of output type in `Signal::split` to resolve a new warning.

## v1.4.0 - 2025-06-22

### Added

- Add `arbiter::{i2c, spi}::BlockingArbiterDevice` which allows sharing of `embedded_hal` (non-async) buses. This also helps during initialization of RTIC apps as you can use the arbiter while in `init`. After initialization is complete, convert an `BlockingArbiterDevice` into an `ArbiterDevice` using `BlockingArbiterDevice::into_non_blocking()`.

### Fixed

- Avoid a critical section when a `send`-link is popped and when returning `free_slot`.

### Changed

- Actually drop items left over in `Channel` on drop of `Receiver`.
- Allow for `split()`-ing a channel more than once without immediately panicking.
- Add `loom` support.
- Avoid a critical section when a `send`-link is popped and when returning `free_slot`.
- Don't force `Signal` import when using `make_signal` macro
- Update `make_signal`'s documentation to match `make_channel`'s

## v1.3.2 - 2025-03-16

### Fixed

- Improve handling of free slots for `send` by explicitly writing the free slot to the awoken future.
- Fix all known instances of #780

## v1.3.1 - 2025-03-12 - yanked

### Fixed

- Fix [#780]

[#780]: https://github.com/rtic-rs/rtic/issues/780

## v1.3.0 - 2024-05-01 - yanked

### Changed

- Unstable features are now stable, the feature flag `unstable` is removed.
- Update `embedded-hal-bus` to 0.2

### Added

- `defmt v0.3` derives added and forwarded to `embedded-hal(-x)` crates.
- signal structure

## v1.2.0 - 2024-01-10 - yanked

### Changed

- Using `embedded-hal` 1.0.

### Fixed

- `make_channel` now accepts `Type` expressions instead of only `TypePath` expressions.

## v1.1.1 - 2023-12-04 - yanked

### Fixed

- Fix features for `docs.rs`

## v1.1.0 - 2023-12-04 - yanked

### Added

- `arbiter::spi::ArbiterDevice` for sharing SPI buses using `embedded-hal-async` traits.
- `arbiter::i2c::ArbiterDevice` for sharing I2C buses using `embedded-hal-async` traits.

## v1.0.3 - yanked

- `portable-atomic` used as a drop in replacement for `core::sync::atomic` in code and macros. `portable-atomic` imported with `default-features = false`, as we do not require CAS.

## v1.0.2 - 2023-08-29 - yanked

### Fixed

- `make_channel` no longer requires the user crate to have `critical_section` in scope

## v1.0.1 - 2023-06-14 - yanked

### Fixed

- `make_channel` could be UB

## v1.0.0 - 2023-05-31 - yanked

- Initial release
