//! A "latest only" value store with unlimited writers and async waiting. Value is always available once initialized.

use crate::signal::{Signal, SignalWriter, Store};
use core::sync::atomic::Ordering::{AcqRel, Acquire, Release};
use core::{future::poll_fn, task::Poll};

/// A "latest only" value store with unlimited writers and async waiting. Value is always available once initialized.
pub struct Watch<T: Copy>(Signal<T>);

impl<T> core::fmt::Debug for Watch<T>
where
    T: core::marker::Copy,
{
    fn fmt(&self, fmt: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        fmt.write_fmt(format_args!(
            "Watch<{}>{{ .. }}",
            core::any::type_name::<T>()
        ))
    }
}

impl<T: Copy> Default for Watch<T> {
    fn default() -> Self {
        Self::new()
    }
}

impl<T: Copy> Watch<T> {
    /// Create a new watch.
    #[cfg(not(loom))]
    pub const fn new() -> Self {
        Self(Signal::new())
    }

    /// Create a new watch.
    #[cfg(loom)]
    pub fn new() -> Self {
        Self(Signal::new())
    }

    /// Split the watch into a writer and reader.
    ///
    /// # Panics
    /// This function calls [`Self::take_reader`] and has the same
    /// panicking behaviour.
    pub fn split(&self) -> (WatchWriter<'_, T>, WatchReader<'_, T>) {
        let reader = self.take_reader();
        let writer = self.writer();
        (writer, reader)
    }

    /// Create a writer for this watch.
    ///
    /// Many writers may exist for a [`Watch`]. However, for concurrent
    /// writes, a [`WatchReader`] is only guaranteed to observe _at least_
    /// one of the writes, not _all_ writes.
    pub const fn writer(&self) -> WatchWriter<'_, T> {
        WatchWriter(self.0.writer())
    }

    /// Try to take the reader for this watch.
    ///
    /// If another, non-dropped [`WatchReader`] exists for this [`Watch`],
    /// `None` is returned.
    pub fn try_take_reader(&self) -> Option<WatchReader<'_, T>> {
        if self.0.reader_alive.swap(true, AcqRel) {
            return None;
        }

        Some(WatchReader { parent: &self.0 })
    }

    /// Take the reader for this watch.
    ///
    /// # Panics
    /// This function panics if another [`WatchReader`] associated
    /// with this `self` is alive (i.e. non-dropped).
    pub fn take_reader(&self) -> WatchReader<'_, T> {
        let Some(reader) = self.try_take_reader() else {
            panic!("Cannot create duplicate reader for `Watch`");
        };

        reader
    }
}

/// Creates a split watch with `'static` lifetime.
#[macro_export]
macro_rules! make_watch {
    ( $T:ty ) => {{
        static WATCH: $crate::watch::Watch<$T> = $crate::watch::Watch::new();

        WATCH.split()
    }};
}

/// Facilitates the writing of values to a Watch.
#[derive(Clone)]
pub struct WatchWriter<'a, T: Copy>(SignalWriter<'a, T>);

impl<T> core::fmt::Debug for WatchWriter<'_, T>
where
    T: core::marker::Copy,
{
    fn fmt(&self, fmt: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        fmt.write_fmt(format_args!(
            "WatchWriter<{}>{{ .. }}",
            core::any::type_name::<T>()
        ))
    }
}

impl<T: Copy> WatchWriter<'_, T> {
    /// Write a value to the Watch.
    pub fn write(&mut self, value: T) {
        self.0.write(value);
    }
}

/// Facilitates the async reading of values from the Watch.
pub struct WatchReader<'a, T: Copy> {
    parent: &'a Signal<T>,
}

impl<T: Copy> Drop for WatchReader<'_, T> {
    fn drop(&mut self) {
        self.parent.reader_alive.store(false, Release);
    }
}

impl<T> core::fmt::Debug for WatchReader<'_, T>
where
    T: core::marker::Copy,
{
    fn fmt(&self, fmt: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        fmt.write_fmt(format_args!(
            "WatchReader<{}>{{ .. }}",
            core::any::type_name::<T>()
        ))
    }
}

impl<T: Copy> WatchReader<'_, T> {
    /// Immediately get the latest value stored in the Signal.
    fn get_inner(&mut self) -> Store<T> {
        critical_section::with(|_| {
            let mut_ptr = self.parent.store.get_mut();
            // SAFETY: in a cs: exclusive access
            unsafe { *mut_ptr.deref() }
        })
    }

    /// Immediately get the seen attribute stored in the Signal.
    fn get_seen(&mut self) -> bool {
        self.parent.seen.load(Acquire)
    }

    /// Mark value as seen.
    fn mark_seen(&mut self) {
        self.parent.seen.store(true, Release);
    }

    /// Returns the latest value, or None if uninitialized.
    pub fn try_get(&mut self) -> Option<T> {
        match self.get_inner() {
            Store::Unset => None,
            Store::Set(value) => {
                self.mark_seen();
                Some(value)
            }
        }
    }

    /// Wait for an unseen value.
    ///
    /// If the current value is unseen it will be returned immediately.
    ///
    /// If current value is already seen, it will wait for a new value to be written and then read it.
    pub async fn changed(&mut self) -> T {
        poll_fn(|ctx| {
            self.parent.waker.register(ctx.waker());

            if self.get_seen() {
                return Poll::Pending;
            }

            match self.get_inner() {
                Store::Unset => Poll::Pending,
                Store::Set(value) => {
                    self.mark_seen();
                    Poll::Ready(value)
                }
            }
        })
        .await
    }
}

#[cfg(test)]
#[cfg(loom)]
mod loom_tests {
    use std::future::Future;

    use super::*;

    #[test]
    fn always_seen() {
        loom::model(|| {
            let watch = Box::leak(Box::new(Watch::new()));
            let (mut writer, mut reader) = watch.split();

            let handle = loom::thread::spawn(move || {
                let pre_seen = reader.get_seen();
                let value = reader.try_get();
                let post_seen = reader.get_seen();

                if let Some(value) = value {
                    // If we get a value from a single write, we
                    // 1. Expect it to be correct
                    assert_eq!(value, 0x1337_1337);
                    // 2. Expect not to have seen any value beforehand
                    assert!(!pre_seen);
                    // 3. Expect to have seen the value afterwards
                    assert!(post_seen);
                } else {
                    // If we don't get a value from a single write, we
                    // 1. Expect not to have seen any value beforehand
                    assert!(!pre_seen);
                    // 2. And expecct not to have seen any value afterwards
                    assert!(!post_seen);
                }
            });

            writer.write(0x1337_1337);

            handle.join().unwrap();
        });
    }

    #[test]
    fn changed_always_seen() {
        loom::model(|| {
            let watch = Box::leak(Box::new(Watch::new()));
            let (mut writer, mut reader) = watch.split();

            let handle = loom::thread::spawn(move || {
                let waker = core::task::Waker::noop();
                let mut cx = core::task::Context::from_waker(waker);

                let pre_seen = reader.get_seen();
                let value = { core::pin::pin!(reader.changed()).as_mut().poll(&mut cx) };
                let post_seen = reader.get_seen();

                if let Poll::Ready(value) = value {
                    // If we get a value from a single write, we
                    // 1. Expect it to be correct
                    assert_eq!(value, 0x1337_1337);
                    // 2. Expect not to have seen any value beforehand
                    assert!(!pre_seen);
                    // 3. Expect to have seen the value afterwards
                    assert!(post_seen);
                } else {
                    // If we don't get a value from a single write, we
                    // 1. Expect not to have seen any value beforehand
                    assert!(!pre_seen);
                    // 2. And expecct not to have seen any value afterwards
                    assert!(!post_seen);
                }
            });

            writer.write(0x1337_1337);

            handle.join().unwrap();
        });
    }
}

#[cfg(test)]
#[cfg(not(loom))]
mod tests {
    use super::*;
    use static_cell::StaticCell;

    #[test]
    fn empty() {
        let (_writer, mut reader) = make_watch!(u32);

        assert!(reader.try_get().is_none());
    }

    #[test]
    fn ping_pong() {
        let (mut writer, mut reader) = make_watch!(u32);

        writer.write(0xde);
        assert!(reader.try_get().is_some_and(|value| value == 0xde));
    }

    #[test]
    fn latest() {
        let (mut writer, mut reader) = make_watch!(u32);

        writer.write(0xde);
        writer.write(0xad);
        writer.write(0xbe);
        writer.write(0xef);
        assert!(reader.try_get().is_some_and(|value| value == 0xef));
    }

    #[test]
    fn no_consumption() {
        let (mut writer, mut reader) = make_watch!(u32);

        writer.write(0xaa);
        assert!(reader.try_get().is_some_and(|value| value == 0xaa));
        assert!(reader.try_get().is_some_and(|value| value == 0xaa));
    }

    #[test]
    #[should_panic]
    fn no_simultaneous_multi_split() {
        fn scary_helper<'a>() -> (WatchWriter<'a, u32>, WatchReader<'a, u32>) {
            make_watch!(u32)
        }
        let (mut _writer1, mut _reader1) = scary_helper();
        let (mut _writer2, mut _reader2) = scary_helper();
    }

    #[test]
    fn allow_non_simultaneous_multi_split() {
        fn scary_helper<'a>() -> (WatchWriter<'a, u32>, WatchReader<'a, u32>) {
            make_watch!(u32)
        }

        let (writer1, reader1) = scary_helper();
        drop((writer1, reader1));

        let (mut _writer2, mut _reader2) = scary_helper();
    }

    #[test]
    fn disallow_simultaneous_multi_read() {
        let watch = Watch::<()>::new();

        let _reader1 = watch.try_take_reader();
        assert!(watch.try_take_reader().is_none());
    }

    #[test]
    fn allow_non_simultaneous_multi_read() {
        let watch = Watch::<()>::new();

        let reader1 = watch.try_take_reader().unwrap();
        drop(reader1);
        assert!(watch.try_take_reader().is_some());
    }

    #[tokio::test]
    async fn pending() {
        let (mut writer, mut reader) = make_watch!(u32);

        writer.write(0xaa);

        assert_eq!(reader.changed().await, 0xaa);
    }

    #[tokio::test]
    async fn changed() {
        static READER: StaticCell<WatchReader<u32>> = StaticCell::new();
        let (mut writer, mut reader) = make_watch!(u32);

        writer.write(0xaa);
        assert_eq!(reader.changed().await, 0xaa);

        let reader = READER.init(reader);
        let handle = tokio::spawn(reader.changed());

        tokio::task::yield_now().await; // encourage tokio executor to poll reader future
        assert!(!handle.is_finished()); // verify reader future did not resolve after poll

        writer.write(0xab);
        assert!(handle.await.is_ok_and(|value| value == 0xab));
    }

    #[tokio::test]
    async fn try_get_marks_seen() {
        static READER: StaticCell<WatchReader<u32>> = StaticCell::new();
        let (mut writer, mut reader) = make_watch!(u32);

        writer.write(0xaa);
        assert!(reader.try_get().is_some_and(|value| value == 0xaa));

        let reader = READER.init(reader);
        let handle = tokio::spawn(reader.changed());

        tokio::task::yield_now().await; // encourage tokio executor to poll reader future
        assert!(!handle.is_finished()); // verify reader future did not resolve after poll
    }
}
